var searchData=
[
  ['fasttext_5ffileformat_5fmagic_5fint32',['FASTTEXT_FILEFORMAT_MAGIC_INT32',['../fasttext_8h.html#af5de14588083ef853a2863c8d625ee24',1,'fasttext.h']]],
  ['fasttext_5fversion',['FASTTEXT_VERSION',['../fasttext_8h.html#a74036bd705019bb33643e90202bf343e',1,'fasttext.h']]]
];
