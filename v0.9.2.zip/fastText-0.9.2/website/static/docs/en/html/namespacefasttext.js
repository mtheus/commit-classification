var namespacefasttext =
[
    [ "Args", "classfasttext_1_1Args.html", "classfasttext_1_1Args" ],
    [ "Dictionary", "classfasttext_1_1Dictionary.html", "classfasttext_1_1Dictionary" ],
    [ "entry", "structfasttext_1_1entry.html", "structfasttext_1_1entry" ],
    [ "FastText", "classfasttext_1_1FastText.html", "classfasttext_1_1FastText" ],
    [ "Matrix", "classfasttext_1_1Matrix.html", "classfasttext_1_1Matrix" ],
    [ "Model", "classfasttext_1_1Model.html", "classfasttext_1_1Model" ],
    [ "Node", "structfasttext_1_1Node.html", "structfasttext_1_1Node" ],
    [ "ProductQuantizer", "classfasttext_1_1ProductQuantizer.html", "classfasttext_1_1ProductQuantizer" ],
    [ "QMatrix", "classfasttext_1_1QMatrix.html", "classfasttext_1_1QMatrix" ],
    [ "Vector", "classfasttext_1_1Vector.html", "classfasttext_1_1Vector" ]
];