var namespaces =
[
    [ "fasttext", "namespacefasttext.html", "namespacefasttext" ]
];